{\rtf1\ansi\ansicpg1252\cocoartf2821
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 class SessionSummarizer:\
    def __init__(self):\
        pass\
\
    def summarize_session(self, session_record, self_assessment_text):\
        summary = []\
        summary.append(f"Session Timestamp: \{session_record['timestamp']\}")\
        summary.append(f"Mode: \{session_record['mode']\}")\
        summary.append(f"Genesis Proto-Symbol: \{session_record.get('proto_symbol', 'N/A')\}")\
        \
        if session_record.get("deepened_paths"):\
            summary.append("\\\\nDeepened Genesis Paths:")\
            for idx, path in enumerate(session_record["deepened_paths"], 1):\
                summary.append(f"Path \{idx\}: \{path\}")\
\
        if session_record.get("meta_theories"):\
            summary.append("\\\\nMeta-Theories Generated:")\
            for idx, theory in enumerate(session_record["meta_theories"], 1):\
                summary.append(f"Meta-Theory \{idx\}: \{theory\}")\
\
        summary.append("\\\\nSelf-Assessment Reflection:")\
        summary.append(self_assessment_text)\
\
        return "\\\\n".join(summary)}