{\rtf1\ansi\ansicpg1252\cocoartf2821
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 import json\
\
class SymbolicResearchMemoryGrowthCurve:\
    def __init__(self):\
        self.growth_data = []\
\
    def record_session(self, session_number, memory_complexity, coherence, divergence, meta_density):\
        self.growth_data.append(\{\
            "session": session_number,\
            "memory_complexity": memory_complexity,\
            "coherence": coherence,\
            "divergence": divergence,\
            "meta_density": meta_density\
        \})\
\
    def export_growth_curve(self, filename="memory_growth_curve.json"):\
        with open(filename, "w") as f:\
            json.dump(\{"symbolic_memory_growth": self.growth_data\}, f, indent=2)}