
import tkinter as tk
from tkinter import messagebox, ttk
from symbolic_grammar import parse_clause
from teaching_mode import generate_teaching
from memory_engine import log_clause
from semantic_adapter import map_input_to_symbolic
from clause_bank import suggest_clause

class RESAGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("RESA | Symbolic Companion")
        self.geometry("700x500")
        self.configure(bg="#f5f5f5")
        self.create_splash()

    def create_splash(self):
        splash = tk.Toplevel(self)
        splash.geometry("400x200+600+300")
        splash.title("Welcome to RESA")
        splash.configure(bg="#f5f5f5")
        label = tk.Label(splash, text="Welcome to RESA", font=("Helvetica", 18, "bold"), bg="#f5f5f5")
        label.pack(pady=20)
        msg = tk.Label(splash, text="Your symbolic reflection companion", font=("Helvetica", 12), bg="#f5f5f5")
        msg.pack()
        self.after(2500, splash.destroy)
        self.after(2500, self.setup_main_window)

    def setup_main_window(self):
        self.label = tk.Label(self, text="Enter your symbolic clause:", font=("Helvetica", 12), bg="#f5f5f5")
        self.label.pack(pady=5)

        self.input_box = tk.Entry(self, width=90, font=("Courier", 11))
        self.input_box.pack(pady=5)
        self.input_box.bind("<Return>", self.process_input)

        self.inspire_button = tk.Button(self, text="Inspire Me", command=self.fill_suggestion)
        self.inspire_button.pack(pady=2)

        self.persona_choice = tk.StringVar(value='Healer')
        persona_dropdown = ttk.Combobox(self, textvariable=self.persona_choice)
        persona_dropdown['values'] = ('Healer', 'Analyst', 'Dreamer')
        persona_dropdown.pack(pady=5)

        self.output_label = tk.Label(self, text="Symbolic Teaching:", font=("Helvetica", 11, "bold"), bg="#f5f5f5")
        self.output_label.pack()

        self.output_area = tk.Text(self, height=5, wrap="word", bg="#ffffff", font=("Georgia", 11))
        self.output_area.pack(pady=5)

        self.log_label = tk.Label(self, text="Clause Log:", font=("Helvetica", 11, "bold"), bg="#f5f5f5")
        self.log_label.pack()

        self.log_area = tk.Text(self, height=10, wrap="word", bg="#ffffff", font=("Courier", 10))
        self.log_area.pack(pady=5)
        self.log_area.configure(state="disabled")

    def process_input(self, event=None):
        raw_text = self.input_box.get()
        symbolic_input = map_input_to_symbolic(raw_text)
        clause = parse_clause(symbolic_input)
        clause['persona'] = self.persona_choice.get()
        if clause:
            log_clause(clause)
            teaching = generate_teaching(clause)
            self.output_area.delete("1.0", tk.END)
            self.output_area.insert(tk.END, teaching)

            self.log_area.configure(state="normal")
            self.log_area.insert(tk.END, f"{clause['raw']}\n")
            self.log_area.configure(state="disabled")
        else:
            self.output_area.delete("1.0", tk.END)
            self.output_area.insert(tk.END, "Could not interpret input.")

        self.input_box.delete(0, tk.END)

    def fill_suggestion(self):
        suggestion = suggest_clause()
        self.input_box.delete(0, tk.END)
        self.input_box.insert(0, suggestion)

if __name__ == "__main__":
    app = RESAGUI()
    app.mainloop()
