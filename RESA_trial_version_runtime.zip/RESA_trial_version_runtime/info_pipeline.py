
from web_client import fetch_web_summary
from contradiction_engine import detect_contradiction
import json
import os

memory_path = os.path.join(os.path.dirname(__file__), 'symbolic_memory_base.json')
with open(memory_path, 'r') as m:
    symbolic_memory = json.load(m)

def evaluate_info(text):
    clause = {'raw': text}
    contradictions = detect_contradiction(clause)
    return contradictions

def integrate_if_valid(keyword, info, contradictions):
    if not contradictions:
        symbolic_memory['practical_knowledge'][keyword] = info
        with open(memory_path, 'w') as f:
            json.dump(symbolic_memory, f, indent=2)
        return f"Symbolic info about '{keyword}' added to memory."
    else:
        return f"Info about '{keyword}' not stored due to contradictions: {', '.join(contradictions)}"

def info_pipeline(query):
    response = fetch_web_summary(query)
    if "Error" in response or "Failed" in response:
        return f"Error fetching info: {response}"
    
    contradictions = evaluate_info(response)
    integration_result = integrate_if_valid(query.lower(), response, contradictions)
    
    return f"Fetched: {response}\n{integration_result}"
