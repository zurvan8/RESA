
def detect_contradiction(clause):
    text = clause.get('raw', '').lower()
    contradictions = []

    if "trust" in text and "control" in text:
        contradictions.append("C⊥ (orthogonal contradiction)")
    if "want" in text and "avoid" in text:
        contradictions.append("Cᵈ (developmental contradiction)")
    if "control" in text and "surrender" in text:
        contradictions.append("C∑ (systemic contradiction)")
    if "believe" in text and "impossible" in text:
        contradictions.append("Cn (narrative contradiction)")

    return contradictions
