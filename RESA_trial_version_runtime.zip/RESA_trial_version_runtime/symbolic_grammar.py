
def parse_clause(text):
    words = text.strip().lower().split()
    if not words:
        return None
    verb = words[0]
    valid_verbs = {'reflect', 'seed', 'mutate', 'teach', 'journal'}
    if verb not in valid_verbs:
        return None
    object_part = ' '.join(words[1:]) if len(words) > 1 else ''
    return {'verb': verb, 'object': object_part, 'raw': text}
