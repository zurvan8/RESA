
import requests

def fetch_web_summary(query, max_chars=500):
    try:
        url = f"https://api.duckduckgo.com/?q={query}&format=json&no_redirect=1&no_html=1"
        response = requests.get(url)
        if response.status_code == 200:
            data = response.json()
            abstract = data.get("Abstract", "")
            if abstract:
                return abstract[:max_chars]
            else:
                return "No summary found. Try rephrasing your query."
        else:
            return f"Failed to fetch summary. HTTP {response.status_code}"
    except Exception as e:
        return f"Error: {str(e)}"
