# RESA (Recursive Emergent Symbolic Analysis)

This repository contains the updated runtime for RESA, a symbolic reasoning and reflection engine capable of clause interpretation, contradiction detection, recursive insight generation, and adaptive symbolic memory.

This version represents an **update** to the earlier release, adding:

- A fully operational Flexible Information Pipeline (FIP)
- Adaptive symbolic memory integration with contradiction filtering
- GUI with persona selector and inspirational clause system
- Symbolic contradiction engine (C⊥, Cᵈ, C∑, Cn)
- Export and review capabilities

## Quickstart

```bash
pip install spacy
python -m spacy download en_core_web_sm
python runtime/gui_interface.py
```

## Features

- Reflective GUI interface with clause input and persona system
- Natural language parsing and clause interpretation
- Teaching generator with fallback symbolic memory
- Contradiction detection and adaptive learning
- Web query integration with symbolic filters
- Memory log, export, and review tools

## Development Notes

This is an **iterative update**, not a new version line. All prior symbolic seeds, memory, and modules have been preserved or enhanced.

To contribute, submit pull requests against the `dev` branch.

## License

See `LICENSE.txt`.
