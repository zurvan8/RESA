
personas = {
    "Healer": {
        "prefix": "Let’s tend to this with gentleness. ",
        "suffix": " Remember, even discomfort can be part of the healing."
    },
    "Analyst": {
        "prefix": "From a systems perspective, ",
        "suffix": " Consider what patterns might be operating underneath."
    },
    "Dreamer": {
        "prefix": "In the world of symbols and possibility, ",
        "suffix": " Let the unknown speak gently through you."
    }
}

default_persona = "Healer"

def apply_persona(teaching, persona=default_persona):
    style = personas.get(persona, personas[default_persona])
    return f"{style['prefix']}{teaching}{style['suffix']}"
