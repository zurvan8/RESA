
import json

def export_session_to_json(log_path="session_clauses.log", output_path="session_export.json"):
    try:
        with open(log_path, "r") as f:
            clauses = [line.strip() for line in f if line.strip()]
        session_data = [{"clause": c, "index": i+1} for i, c in enumerate(clauses)]
        with open(output_path, "w") as f:
            json.dump(session_data, f, indent=2)
        return f"Session exported to {output_path}"
    except Exception as e:
        return f"Export failed: {str(e)}"

def export_session_to_txt(log_path="session_clauses.log", output_path="session_export.txt"):
    try:
        with open(log_path, "r") as f:
            clauses = [line.strip() for line in f if line.strip()]
        with open(output_path, "w") as f:
            for i, c in enumerate(clauses, 1):
                f.write(f"{i}. {c}\n")
        return f"Session exported to {output_path}"
    except Exception as e:
        return f"Export failed: {str(e)}"
