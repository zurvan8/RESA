
try:
    import spacy
    nlp = spacy.load("en_core_web_sm")
except:
    nlp = None
    print("spaCy not installed or model missing.")

def map_input_to_symbolic(text):
    if not nlp:
        return text.lower()
    doc = nlp(text)
    verb = None
    obj = []
    for token in doc:
        if token.pos_ == "VERB" and not verb:
            verb = token.lemma_
        elif token.pos_ in {"NOUN", "ADJ", "PROPN", "PRON"}:
            obj.append(token.text)
    return f"{verb or 'reflect'} {' '.join(obj)}"
