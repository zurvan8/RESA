
log_path = "session_clauses.log"

def log_clause(clause):
    with open(log_path, "a") as f:
        f.write(f"{clause['raw']}\n")
