
import random

sample_clauses = [
    "reflect fear of failure",
    "seed trust in the unknown",
    "mutate self-doubt into possibility",
    "teach me how to pause",
    "journal recurring dreams"
]

def suggest_clause():
    return random.choice(sample_clauses)
